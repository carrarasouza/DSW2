package br.ufscar.dc.dsw.SistemaAgendamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaAgendamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
